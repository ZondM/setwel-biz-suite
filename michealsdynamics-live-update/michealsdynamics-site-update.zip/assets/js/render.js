/* Shared HTML building blocks. Used in the browser (window.MDR) and by tools/build.js. */
(function (root) {
  var R = {};
  var MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  R.esc = function (s) { return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, function (c) { return MAP[c]; }); };
  R.money = function (n) {
    var p = (Math.round(Number(n) * 100) / 100).toFixed(2).split('.');
    return 'R' + p[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',') + '.' + p[1];
  };
  R.rand = function (n) { return R.money(n).replace(/\.00$/, ''); };
  R.hasPrice = function (o) { return o && o.price !== null && o.price !== undefined && o.price !== '' && !isNaN(Number(o.price)); };
  R.isOut = function (o) { return o && String(o.stock || '').toLowerCase() === 'out'; };
  R.isLow = function (o) { return o && String(o.stock || '').toLowerCase() === 'low'; };
  R.minPrice = function (p) {
    var v = p.options.filter(R.hasPrice).map(function (o) { return Number(o.price); });
    return v.length ? Math.min.apply(null, v) : null;
  };
  /* Photos first: products with a photo before products without (keeps the original order otherwise) */
  R.hasPhoto = function (p) { return !!(p.photos && p.photos.length); };
  R.photoFirst = function (list) {
    return list.map(function (p, i) { return [p, i]; }).sort(function (a, b) { return (R.hasPhoto(b[0]) - R.hasPhoto(a[0])) || (a[1] - b[1]); }).map(function (x) { return x[0]; });
  };
  /* Specials: an option with  was: 190.00  higher than its price */
  R.wasOf = function (o) { return o && R.hasPrice(o) && Number(o.was) > Number(o.price) ? Number(o.was) : null; };
  /* special: true on a product, or an option with a  was  price */
  R.isSpecial = function (p) { return !!R.specialOpt(p); };
  R.specialOpt = function (p) {
    var ok = p.options.filter(function (x) { return R.hasPrice(x) && !R.isOut(x) && (p.special === true || R.wasOf(x) !== null); });
    ok.sort(function (a, b) { return a.price - b.price; });
    return ok[0] || null;
  };
  R.pctOff = function (o) { return R.wasOf(o) ? Math.round((R.wasOf(o) - o.price) / R.wasOf(o) * 100) : 0; };
  R.wasHtml = function (o) { return R.wasOf(o) ? '<s>' + R.money(R.wasOf(o)) + '</s> ' : ''; };
  R.specials = function (data) { return R.photoFirst(data.products.filter(R.isSpecial)); };
  R.cat = function (data, slug) { return data.categories.filter(function (c) { return c.slug === slug; })[0] || null; };
  R.catByCode = function (data, code) { return data.categories.filter(function (c) { return c.code === code; })[0] || null; };
  R.catChain = function (data, cat) { // root ... cat
    var chain = [], c = cat, guard = 0;
    while (c && guard++ < 6) { chain.unshift(c); c = c.parent ? R.catByCode(data, c.parent) : null; }
    return chain;
  };
  R.catUrl = function (data, c) {
    if (c.level === 0 && data.groups) { var g = data.groups.filter(function (x) { return x.roots && x.roots.length === 1 && x.roots[0] === c.code; })[0]; if (g) return '/shop/' + g.slug + '/'; }
    if (c.level >= 2) { var l1 = R.catByCode(data, c.parent); return '/shop/' + (l1 ? l1.slug : c.slug) + '/?sub=' + encodeURIComponent(c.code); }
    return '/shop/' + c.slug + '/';
  };
  /* Description text: keeps line breaks, "Key: value" lines get a bold key */
  R.textHtml = function (t) {
    return String(t || '').split(/\n{2,}/).map(function (para) {
      return '<p>' + para.split('\n').map(function (line) {
        var m = line.match(/^([^:]{2,40}):\s*(.+)$/);
        return m && !/^https?$/i.test(m[1]) ? '<b>' + R.esc(m[1]) + ':</b> ' + R.esc(m[2]) : R.esc(line);
      }).join('<br>') + '</p>';
    }).join('');
  };
  R.group = function (data, slug) { return (data.groups || []).filter(function (g) { return g.slug === slug; })[0] || null; };
  R.groupCats = function (data, g) { return data.categories.filter(function (c) { return c.group === g; }); };
  R.productUrl = function (p, built) {
    if (p.url) return p.url;
    return built && built.indexOf(p.slug) !== -1 ? '/product/' + p.slug + '/' : '/product/?p=' + encodeURIComponent(p.slug);
  };
  R.photo = function (file) { return /^https?:\/\//.test(file) ? file : '/images/products/' + encodeURIComponent(file); };
  R.waLink = function (s, text) {
    return 'https://wa.me/' + String(s.whatsapp || '').replace(/\D/g, '') + '?text=' + encodeURIComponent(text || 'Hi ' + s.trading_name + ', I would like to place an order:');
  };
  R.tel = function (n) { return 'tel:' + String(n || '').replace(/\s/g, ''); };
  R.packText = function (p) {
    if (!p.pack || p.pack <= 1) return '';
    var u = p.unit || 'item';
    return p.pack + ' ' + u + (/(s|sh|ch|x)$/.test(u) ? 'es' : 's') + ' per pack';
  };
  R.tags = function (p) {
    var t = '';
    var sp = R.specialOpt(p);
    if (sp && !p.badge) t += '<span class="tag tag--special">' + (R.pctOff(sp) ? 'Special −' + R.pctOff(sp) + '%' : 'Special price') + '</span>';
    if (p.sterile === true) t += '<span class="tag tag--solid">Sterile</span>';
    if (p.sterile === false) t += '<span class="tag">Non-sterile</span>';
    if (p.pack > 1) t += '<span class="tag">Pack of ' + R.esc(p.pack) + '</span>';
    return t ? '<div class="card__tags">' + t + '</div>' : '';
  };
  R.img = function (p, cls, eager, big) {
    var src = (!big && p.thumb) || (p.photos && p.photos[0]);
    if (src) {
      return '<img class="' + (cls || '') + '" src="' + R.esc(R.photo(src)) + '" alt="' + R.esc(p.name) + '" width="600" height="600" referrerpolicy="no-referrer"' + (eager ? '' : ' loading="lazy"') + ' onerror="this.onerror=null;this.src=\'/assets/img/placeholder.svg\'">';
    }
    return '<img class="' + (cls || '') + '" src="/assets/img/placeholder.svg" alt="' + R.esc(p.name) + ' — photo coming soon" width="600" height="600"' + (eager ? '' : ' loading="lazy"') + '>';
  };
  R.card = function (p, built) {
    var url = R.esc(R.productUrl(p, built));
    var min = R.minPrice(p);
    var allOut = p.options.every(R.isOut);
    var sp = R.specialOpt(p);
    var price = sp
      ? '<p class="card__price">' + (R.wasOf(sp) ? '<s class="was">' + R.money(R.wasOf(sp)) + '</s> ' : '') + '<span class="now">' + R.money(sp.price) + '</span>' +
        (p.pack > 1 ? ' <small>(' + R.money(sp.price / p.pack) + ' per ' + R.esc(p.unit || 'item') + ')</small>' : '') + '</p>' +
        '<p class="stock stock--in">In stock</p>'
      : min !== null
      ? '<p class="card__price">' + (p.options.filter(R.hasPrice).some(function (o) { return Number(o.price) !== min; }) ? 'From ' : '') + R.money(min) +
        (p.pack > 1 ? ' <small>(' + R.money(min / p.pack) + ' per ' + R.esc(p.unit || 'item') + ')</small>' : '') + '</p>' +
        '<p class="stock stock--' + (allOut ? 'out' : R.isLow(p.options[0]) ? 'low' : 'in') + '">' + (allOut ? 'Out of stock' : R.isLow(p.options[0]) ? 'Low stock' : 'In stock') + '</p>'
      : '<p class="card__price card__price--req">Price on request</p>' + (allOut ? '<p class="stock stock--out">Out of stock</p>' : '');
    return '<article class="card"><a href="' + url + '" class="card__img">' + R.img(p) + '</a><div class="card__body">' + R.tags(p) +
      '<h3 class="card__title"><a href="' + url + '">' + R.esc(p.name) + '</a></h3>' + price + '</div></article>';
  };

  /* Moving 3D specials showcase (animated by app.js) */
  R.specialsBlock = function (data, built) {
    var list = R.specials(data);
    if (!list.length) return '';
    var items = list.slice();
    while (items.length < 8) items = items.concat(list); // keep the ring full
    var card = function (p) {
      var o = R.specialOpt(p), url = R.esc(R.productUrl(p, built));
      return '<div class="sp3d__item"><a class="sp3d__card" href="' + url + '" draggable="false">' +
        '<span class="sp3d__badge">' + (R.pctOff(o) ? '−' + R.pctOff(o) + '%' : R.esc(p.badge || 'SPECIAL')) + '</span>' +
        '<span class="sp3d__img">' + R.img(p, '', true).replace('<img ', '<img draggable="false" ') + '</span>' +
        '<span class="sp3d__name">' + R.esc(p.name) + '</span>' +
        '<span class="sp3d__prices">' + R.wasHtml(o) + '<b>' + R.money(o.price) + '</b></span>' +
        '<span class="sp3d__save">' + (R.wasOf(o) ? 'You save ' + R.money(R.wasOf(o) - o.price) : R.esc(p.badge_text || 'Special price')) + '</span>' +
        '<span class="sp3d__cta">' + (p.badge ? 'View product →' : 'View special →') + '</span></a></div>';
    };
    var tick = list.map(function (p) { var o = R.specialOpt(p); return '<span>★ ' + R.esc(p.name) + ' ' + R.wasHtml(o) + '<b>' + R.money(o.price) + '</b></span>'; }).join('');
    return '<div class="sp3d" data-spin>' +
      '<div class="sp3d__ticker" aria-hidden="true"><div class="sp3d__track">' + tick + tick + tick + tick + '</div></div>' +
      '<div class="sp3d__stage"><div class="sp3d__ring">' + items.map(card).join('') + '</div></div>' +
      '<div class="sp3d__ctrl"><button type="button" data-spin-prev aria-label="Previous special">‹</button>' +
      '<button type="button" data-spin-pause aria-label="Pause the moving showcase">❚❚ Pause</button>' +
      '<button type="button" data-spin-next aria-label="Next special">›</button></div></div>';
  };

  /* Product page: photos + information + buy box */
  R.gallery = function (p) {
    var main = '<div class="pdp__main">' + R.img(p, '', true, true).replace('<img ', '<img id="pdp-main" ') + '</div>';
    var thumbs = p.photos && p.photos.length > 1
      ? '<div class="thumbs">' + p.photos.map(function (f) {
          return '<button type="button" data-src="' + R.esc(R.photo(f)) + '" aria-label="Show photo"><img src="' + R.esc(R.photo(f)) + '" alt="" width="80" height="80" loading="lazy" referrerpolicy="no-referrer"></button>';
        }).join('') + '</div>'
      : '';
    return main + thumbs;
  };
  R.optionState = function (o) {
    if (R.isOut(o)) return { key: 'out', text: 'Out of stock' };
    if (R.isLow(o) && R.hasPrice(o)) return { key: 'low', text: 'Low stock — order soon' };
    if (!R.hasPrice(o)) return { key: 'request', text: '' };
    return { key: 'in', text: 'In stock' };
  };
  R.buyBox = function (p, s) {
    var first = p.options.filter(function (o) { return !R.isOut(o); })[0] || p.options[0];
    var single = p.options.length === 1;
    var opts = single
      ? '<input type="hidden" name="option" value="' + R.esc(first.label) + '">'
      : '<fieldset class="opts"><legend>Choose ' + R.esc((p.option_name || 'option').toLowerCase()) + '</legend>' +
        p.options.map(function (o) {
          return '<label class="opt"><input type="radio" name="option" value="' + R.esc(o.label) + '"' + (o === first ? ' checked' : '') + '><span>' + R.esc(o.label) + '</span></label>';
        }).join('') + '</fieldset>';
    var bulk = p.bulk && p.bulk.length
      ? '<div class="tiers"><b>Bulk discount</b><table><tbody>' + p.bulk.map(function (b) {
          return '<tr><td>' + R.esc(b.from) + ' or more</td><td>' + R.esc(b.discount) + '% off</td></tr>';
        }).join('') + '</tbody></table></div>'
      : '';
    return '<form class="buy" id="buy" data-slug="' + R.esc(p.slug) + '">' + opts +
      '<p class="pdp__price" id="price"></p><p class="pdp__peritem" id="peritem"></p><p class="stock" id="stock"></p>' +
      '<div class="buy__row"><div class="qty"><button type="button" data-step="-1" aria-label="Less">−</button>' +
      '<input id="qty" name="qty" type="number" min="1" max="9999" value="1" inputmode="numeric" aria-label="Quantity">' +
      '<button type="button" data-step="1" aria-label="More">+</button></div>' +
      '<button class="btn" id="addbtn" type="submit">Add to order</button></div>' +
      '<p class="muted small" id="reqnote" hidden>No price yet — add it to your order and we\'ll reply with the price before you pay.</p>' +
      '<p class="flash flash--ok" id="added" hidden role="status">Added to your order. <a href="/cart/">View order</a></p>' +
      bulk + '</form>' +
      '<p class="pdp__links"><a href="/quote/?item=' + encodeURIComponent(p.name) + '">Bulk or institutional order? Request a quote</a> · ' +
      '<a href="' + R.esc(R.waLink(s, 'Hi, I have a question about: ' + p.name)) + '" target="_blank" rel="noopener">Ask on WhatsApp</a></p>';
  };
  R.specs = function (p, cat) {
    var rows = [['Category', cat ? cat.name : ''], ['Barcode', p.barcode], ['Material', p.material], ['Sterility', p.sterile === true ? 'Sterile' : p.sterile === false ? 'Non-sterile' : ''],
      ['Pack size', R.packText(p) || (p.pack ? p.pack + ' ' + (p.unit || '') : '')], [p.option_name || '', p.options.length > 1 ? p.options.map(function (o) { return o.label; }).join(', ') : ''],
      ['Product code', p.sku]];
    return '<table class="specs"><tbody>' + rows.filter(function (r) { return r[0] && r[1]; }).map(function (r) {
      return '<tr><th>' + R.esc(r[0]) + '</th><td>' + R.esc(r[1]) + '</td></tr>';
    }).join('') + (p.specs || []).map(function (x) {
      var m = String(x).split(/:\s*/);
      return m.length > 1 ? '<tr><th>' + R.esc(m[0]) + '</th><td>' + R.esc(m.slice(1).join(': ')) + '</td></tr>' : '<tr><td colspan="2">' + R.esc(x) + '</td></tr>';
    }).join('') + '</tbody></table>';
  };
  /* Optional extra sections: [{title, items:[...]}] or [{title, table:{head:[...], rows:[[...]]}}] */
  R.sections = function (p) {
    return (p.sections || []).map(function (s) {
      var body = '';
      if (s.table) {
        body = '<table class="specs"><thead><tr>' + (s.table.head || []).map(function (h) { return '<th>' + R.esc(h) + '</th>'; }).join('') + '</tr></thead><tbody>' +
          (s.table.rows || []).map(function (r) { return '<tr>' + r.map(function (c) { return '<td>' + R.esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table>';
      }
      if (s.items) body += '<ul>' + s.items.map(function (i) { return '<li>' + R.esc(i) + '</li>'; }).join('') + '</ul>';
      if (s.text) body += '<p>' + R.esc(s.text) + '</p>';
      return '<h2>' + R.esc(s.title) + '</h2>' + body;
    }).join('');
  };
  R.productBody = function (p, data) {
    var cat = R.cat(data, p.category), grp = cat ? R.group(data, cat.group) : null;
    var chain = cat ? R.catChain(data, cat) : [];
    var crumbs = '<a href="/">Home</a> / <a href="/shop/">Shop</a>' +
      (grp ? ' / <a href="/shop/' + R.esc(grp.slug) + '/">' + R.esc(grp.name) + '</a>' : '') +
      chain.filter(function (c) { return !(c.level === 0 && grp && grp.roots && grp.roots.length === 1); }).map(function (c) { return ' / <a href="' + R.esc(R.catUrl(data, c)) + '">' + R.esc(c.name) + '</a>'; }).join('') +
      ' / ' + R.esc(p.name);
    return '<div class="wrap section">' +
      '<nav class="crumbs" aria-label="Breadcrumb">' + crumbs + '</nav>' +
      '<div class="pdp"><div class="pdp__gallery" data-part="gallery">' + R.gallery(p) + '</div>' +
      '<div class="pdp__info">' + R.tags(p) + '<h1>' + R.esc(p.name) + '</h1>' +
      '<div data-part="buy">' + R.buyBox(p, data.settings) + '</div>' +
      (p.description ? '<div class="prose"><h2>Description &amp; specifications</h2>' + R.textHtml(p.description) + '</div>' : '') +
      (p.extra ? '<div class="prose"><h2>Additional information</h2>' + R.textHtml(p.extra) + '</div>' : '') +
      '<h2>Product details</h2>' + R.specs(p, cat) + R.sections(p) +
      '<p class="muted small">Product information is for identification only and is not medical advice. Use as directed by the manufacturer and a qualified healthcare professional.</p>' +
      '</div></div></div>';
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = R; else root.MDR = R;
})(this);
