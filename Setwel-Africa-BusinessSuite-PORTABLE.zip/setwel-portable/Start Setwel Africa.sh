#!/bin/bash
# Setwel Africa Business Suite — macOS / Linux launcher
# Double-click this file in Finder (macOS) or run: bash "Start Setwel Africa.sh"

clear
echo ""
echo "  ===================================================="
echo "    Setwel Africa Business Suite — Starting up..."
echo "  ===================================================="
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "  ERROR: Node.js is not installed."
    echo ""
    echo "  Install options:"
    echo "  • macOS:  brew install node   (or https://nodejs.org)"
    echo "  • Ubuntu: sudo apt install nodejs npm"
    echo ""
    echo "  After installing Node.js, run this script again."
    exit 1
fi

NODE_VER=$(node --version)
echo "  Node.js $NODE_VER found. Starting server..."
echo ""
echo "  App will open at http://localhost:3000"
echo "  Press Ctrl+C to stop."
echo ""

# Run from the directory this script is in
cd "$(dirname "$0")"
node server.js
