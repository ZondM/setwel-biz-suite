/**
 * Setwel Africa Business Suite — Local Server
 * Zero npm dependencies. Uses only Node.js built-ins.
 * Run: node server.js
 */
const http = require('http');
const fs   = require('fs');
const path = require('path');

const PORT = 3000;
const DIST = path.join(__dirname, 'dist');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'application/javascript',
  '.css':  'text/css',
  '.wasm': 'application/wasm',
  '.png':  'image/png',
  '.svg':  'image/svg+xml',
  '.ico':  'image/x-icon',
  '.json': 'application/json',
  '.woff2':'font/woff2',
  '.woff': 'font/woff',
  '.ttf':  'font/ttf',
};

const server = http.createServer((req, res) => {
  let urlPath = req.url.split('?')[0];
  let filePath = path.join(DIST, urlPath);

  // Hash-router: any path that isn't a real file serves index.html
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    filePath = path.join(DIST, 'index.html');
  }

  const ext  = path.extname(filePath).toLowerCase();
  const mime = MIME[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    res.writeHead(200, {
      'Content-Type': mime,
      'Cache-Control': 'no-cache',
    });
    res.end(data);
  });
});

server.listen(PORT, '127.0.0.1', () => {
  const url = `http://localhost:${PORT}`;
  console.log('\n╔════════════════════════════════════════════╗');
  console.log('║   Setwel Africa Business Suite            ║');
  console.log('║   Running at ' + url + '         ║');
  console.log('║   Press Ctrl+C to stop                    ║');
  console.log('╚════════════════════════════════════════════╝\n');

  const { exec } = require('child_process');
  const open =
    process.platform === 'win32'  ? `start ${url}` :
    process.platform === 'darwin' ? `open ${url}`  :
                                    `xdg-open ${url}`;
  exec(open);
});
