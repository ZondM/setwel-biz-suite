/* =====================================================================
   MICHEALS DYNAMICS — SHOP SETTINGS
   Business details, featured products and specials.
   Products, photos, descriptions and prices come from the Transpharm import
   (tools/import-transpharm.js) and are rebuilt with tools/build.js.

   FEATURED:  featured: ["99591EA", "12345EA"],   product codes shown on the home page
              and in the moving showcase. Leave empty [] to pick them automatically.
   SPECIALS:  specials: [{ code: "99591EA", price: 199.99 }],
              a special price for a product (lower than its normal price).
              When there are specials, the moving showcase shows them.
   After editing this file, upload it to the  data  folder. Changes to featured
   products or specials also need a rebuild (node tools/build.js).
   Keep every comma, quote mark and bracket.
   ===================================================================== */

window.MD = {

  /* ---------- Business details (shown in header, footer, contact and legal pages) ---------- */
  settings: {
    business_name: "Micheals Dynamics Results (Pty) Ltd",
    trading_name: "Micheals Dynamics",
    reg_no: "2024/551935/07",
    sahpra_no: "00005896MD",
    address: "33483 Hluhla Street, Harare, Khayelitsha, Cape Town, 7784",
    phone_1: "074 742 3962",
    phone_2: "061 583 3802",            // second phone number (calls only; leave empty to hide)
    whatsapp: "27747423962",            // WhatsApp number, international format, digits only (27 + number without the 0)
    email: "michealsdynamicresults@gmail.com",
    hours: "",                          // e.g. "Mon–Fri 08:00–17:00, Sat 08:00–12:00"
    directors: "Akhona Sawulisi",                      // shown on the Terms page (required by law)
    info_officer: "",                   // shown on the Privacy page (required by POPIA)
    google_business_link: "",

    /* Delivery */
    free_delivery_from: 2000,           // Rand. Orders this size or bigger get free delivery
    cut_off_time: "14:00",
    cape_town_postcodes: "7100-7999, 8000-8099",
    cape_town_delivery_fee: null,       // Rand, e.g. 80   (null = "we'll confirm")
    nationwide_delivery_fee: null,      // Rand, e.g. 150  (null = "we'll confirm")
    allow_collection: true,             // customers may collect in Khayelitsha

    /* Bank details for EFT (shown after an order is sent). Leave empty to hide. */
    bank_name: "",
    bank_account_name: "",
    bank_account_number: "",
    bank_branch_code: "",
    bank_account_type: "",

    /* Optional: free key from web3forms.com so orders and forms arrive by email
       automatically. If empty, the customer's own email app opens instead. */
    web3forms_key: ""
  },

  /* ---------- Featured products and specials (product codes from the product pages) ---------- */
  featured: [],
  specials: []
};
