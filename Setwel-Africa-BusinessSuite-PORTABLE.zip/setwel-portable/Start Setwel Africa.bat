@echo off
title Setwel Africa Business Suite
color 0A

echo.
echo  ====================================================
echo    Setwel Africa Business Suite — Starting up...
echo  ====================================================
echo.

:: Check that Node.js is installed
where node >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo  ERROR: Node.js is not installed on this computer.
    echo.
    echo  Please install Node.js from: https://nodejs.org
    echo  Choose the "LTS" version. The install takes about 2 minutes.
    echo.
    echo  After installing Node.js, double-click this file again.
    echo.
    start https://nodejs.org
    pause
    exit /b 1
)

:: Show Node version
for /f "tokens=*" %%v in ('node --version') do set NODE_VER=%%v
echo  Node.js %NODE_VER% found. Good to go!
echo.
echo  Starting Setwel Africa on http://localhost:3000 ...
echo  Your browser will open automatically.
echo.
echo  To stop the app, close this window or press Ctrl+C.
echo.

:: Start the server (stays running in this window)
node "%~dp0server.js"

pause
